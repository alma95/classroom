/* ======= Model ======= */

var model = {
    currentCourse: null,
    courses: []
};

/* ======= Octopus ======= */

var octopus = {

    init: function() {
        // set our current course to the first one in the list
        //model.currentCourse = model.courses[0];
        $.getJSON('http://0.0.0.0:5000/courseInfo', function(data) {
            model.courses = data;
            console.log("JSON request recieved: " + data);
            //console.log(data['courses'])
            model.currentCourse = model.courses[0];
            // tell our views to initialize
            courseListView.init();
        });
    },

    getCurrentCourse: function() {
        return model.currentCourse;
    },

    getCourses: function() {
        return model.courses;
    },

    // set the currently-selected course to the object passed in
    setCurrentcourse: function(course) {
        model.currentCourse = course;
    },

};


/* ======= View ======= */

var courseListView = {

    init: function()
    {
        // store the DOM element for easy access later
        this.courseListElem = document.getElementById('courseID');

        // render this view (update the DOM elements with the right values)
        this.render();
    },

    render: function()
    {
        // get the courses we'll be rendering from the octopus
        var courses = octopus.getCourses();

        // empty the course list
        this.courseListElem.innerHTML = '';

        console.log("courses are : " + courses)
        console.log("first course is : " + courses[0]['students'])

        // loop over the courses
        var course, elem, i;
        for (i = 0; i < courses.length; i++)
        {
            // this is the course we're currently looping over
            course = courses[i];

            // make a new course list item and set its text
            elem = document.createElement('option');
            elem.textContent = course['name'];
            elem.id = course['id']
            //elem.value = course.name;

            // finally, add the element to the list
            this.courseListElem.appendChild(elem);
        }
    }
};

// make it go!
octopus.init();

$('#courseID').change(function()
{
    var idOfSelection = $(this).prop('selectedIndex');
    var courseNum = parseInt(idOfSelection)

    console.log("id of selection: " + courseNum)
    console.log("index of selection: " + $(this).prop('selectedIndex'))

    // get teacher for selected course from model
    $('#teacherID').val(model.courses[courseNum]['teacher']);

    // empty the students list
    $('#studentsInCourseOutput').val('');

    console.log("recieved courses: " + model.courses[courseNum])

    for (const student in model.courses[courseNum]['students']) {

        console.log("student is : " + student)

        $('#studentsInCourseOutput').val(function(i, text) {
            return text + model.courses[courseNum]['students'][student] + "\n";
            //return student + "\n";
        });
    }

    document.getElementById('courseID').readOnly = true;
});


// called from html when student is added - "Add Student" button is clicked
function studentAdded()
{
    // get id of selected class
    var idOfSelection = $('#courseID').prop('selectedIndex');
    var courseNum = parseInt(idOfSelection);

    const numStudents = model.courses[courseNum].students.length;
    model.courses[courseNum].students[numStudents] = $('#studentName').val();

    $.post("/addstudent", { StudentName : $("#studentName").val(), CourseName: model.courses[courseNum]['name'] }, function(data){ alert("Add successful"); }, 'json');

    // add new student in course to output text area
    $('#studentsInCourseOutput').val(function(i, text) {
        return text + model.courses[courseNum]['students'][numStudents] + "\n";
    });
}

$("#SortAsc").click(  function()
{
    alert("clicked");
});



// $("#target" ).submit(function( event ) 
// {
//     alert( "Handler for .submit() called." );
//     event.preventDefault();

//     // get id of selected class
//     var idOfSelection = $('#courseID').prop('selectedIndex');
//     var courseNum = parseInt(idOfSelection);

//     const numStudents = model.courses[courseNum].students.length;
//     model.courses[courseNum].students[numStudents] = $('#studentName').val();

//     // add new student in course to output text area
//     $('#studentsInCourseOutput').val(function(i, text) {
//         return text + model.courses[courseNum]['students'][numStudents] + "\n";
//     });
// });






